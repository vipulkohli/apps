package com.androidunleashed.linearlayoutapp;

import android.os.Bundle;
import android.app.Activity;

public class LinearLayoutAppActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linear_layout_app);
    }

   
}
