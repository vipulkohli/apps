/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.relativelayoutapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}