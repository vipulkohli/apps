package com.androidunleashed.relativelayoutapp;

import android.os.Bundle;
import android.app.Activity;

public class RelativeLayoutAppActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative_layout_app);
    }
}
