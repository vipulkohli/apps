package com.androidunleashed.tablelayoutapp;

import android.os.Bundle;
import android.app.Activity;

public class TableLayoutAppActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table_layout_app);
    }

   
}
