/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.screenorientationapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}