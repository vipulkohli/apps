/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.menuapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}