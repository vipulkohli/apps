/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.listviewapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}