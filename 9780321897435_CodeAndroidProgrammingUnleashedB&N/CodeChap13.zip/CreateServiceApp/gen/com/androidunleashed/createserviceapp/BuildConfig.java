/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.createserviceapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}