/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.phonecallapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}