/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.receivesmsapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}