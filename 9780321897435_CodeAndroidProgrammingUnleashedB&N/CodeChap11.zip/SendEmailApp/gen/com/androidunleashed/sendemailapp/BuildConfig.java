/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.sendemailapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}