/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.sendsmsapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}