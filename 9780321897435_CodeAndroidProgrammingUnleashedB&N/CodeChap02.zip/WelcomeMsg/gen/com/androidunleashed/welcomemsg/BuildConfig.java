/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.welcomemsg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}