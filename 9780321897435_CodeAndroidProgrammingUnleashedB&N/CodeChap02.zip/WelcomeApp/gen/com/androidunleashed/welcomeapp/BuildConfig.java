/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.welcomeapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}