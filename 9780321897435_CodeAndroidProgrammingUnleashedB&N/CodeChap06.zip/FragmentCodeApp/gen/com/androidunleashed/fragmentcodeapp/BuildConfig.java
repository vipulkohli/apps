/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.fragmentcodeapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}