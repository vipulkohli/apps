package com.androidunleashed.scrollviewapp;

import android.os.Bundle;
import android.app.Activity;


public class ScrollViewAppActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scroll_view_app);
    }

   
}
