/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.dispimageapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}