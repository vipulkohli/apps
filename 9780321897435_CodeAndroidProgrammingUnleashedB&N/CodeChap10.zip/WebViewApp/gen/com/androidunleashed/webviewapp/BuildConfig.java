/** Automatically generated file. DO NOT MODIFY */
package com.androidunleashed.webviewapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}